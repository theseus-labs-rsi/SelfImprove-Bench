# Copyright (c) Nex-AGI. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Nexau - A general-purpose agent framework.

To use Nexau core functionality:
    from nexau import Agent, AgentConfig, LLMConfig

To use transports:
    from nexau.transports import SSETransportServer, TransportConfig
"""

from .archs.llm import LLMConfig
from .archs.main_sub.agent import Agent
from .archs.main_sub.config import AgentConfig
from .archs.main_sub.skill import Skill
from .archs.tool import Tool
from .archs.tracer import BaseTracer, CompositeTracer, Span, SpanType, TraceContext

__all__ = [
    "Agent",
    "Tool",
    "LLMConfig",
    "AgentConfig",
    "Skill",
    # Tracer components
    "BaseTracer",
    "CompositeTracer",
    "Span",
    "SpanType",
    "TraceContext",
]
