# Copyright (c) Nex-AGI. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Data structures for parsed tool calls, sub-agent calls, and batch operations."""

import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any

from .model_response import ModelResponse


class CallType(Enum):
    """Types of executable calls."""

    TOOL = "tool"
    SUB_AGENT = "sub_agent"
    BATCH_AGENT = "batch_agent"


@dataclass
class ToolCall:
    """Represents a parsed tool call."""

    tool_name: str
    parameters: dict[str, Any]
    raw_content: str | None = None  # Original representation for error reporting/debugging
    tool_call_id: str | None = None
    source: str = "xml"
    parallel_execution_id: str | None = None  # ID for grouping parallel executions

    def __post_init__(self):
        if self.tool_call_id is None:
            self.tool_call_id = "tool_call_" + str(uuid.uuid4())

    @property
    def xml_content(self) -> str | None:  # pragma: no cover - backward compatibility
        return self.raw_content


@dataclass
class SubAgentCall:
    """Represents a parsed sub-agent call."""

    agent_name: str
    message: str
    raw_content: str | None = None  # Original representation for error reporting/debugging
    tool_call_id: str | None = None
    sub_agent_call_id: str | None = None
    parallel_execution_id: str | None = None  # ID for grouping parallel executions

    def __post_init__(self):
        if self.sub_agent_call_id is None:
            self.sub_agent_call_id = "sub_agent_call_" + str(uuid.uuid4())

    @property
    def xml_content(self) -> str | None:  # pragma: no cover - backward compatibility
        return self.raw_content


@dataclass
class BatchAgentCall:
    """Represents a parsed batch agent call."""

    agent_name: str
    file_path: str
    data_format: str
    message_template: str
    raw_content: str | None = None  # Original representation for error reporting/debugging
    batch_agent_call_id: str | None = None

    def __post_init__(self):
        if self.batch_agent_call_id is None:
            self.batch_agent_call_id = "batch_agent_call_" + str(uuid.uuid4())

    @property
    def xml_content(self) -> str | None:  # pragma: no cover - backward compatibility
        return self.raw_content


# Union type for all call types
ExecutableCall = ToolCall | SubAgentCall | BatchAgentCall


@dataclass
class ParsedResponse:
    """Container for all parsed calls from an LLM response."""

    original_response: str
    tool_calls: list[ToolCall]
    sub_agent_calls: list[SubAgentCall]
    batch_agent_calls: list[BatchAgentCall]
    is_parallel_tools: bool = False
    is_parallel_sub_agents: bool = False
    model_response: ModelResponse | None = None

    def get_all_calls(self) -> list[ExecutableCall]:
        """Get all calls in execution order."""
        all_calls: list[ToolCall | SubAgentCall | BatchAgentCall] = []
        all_calls.extend(self.tool_calls)
        all_calls.extend(self.sub_agent_calls)
        all_calls.extend(self.batch_agent_calls)
        return all_calls

    def has_calls(self) -> bool:
        """Check if there are any calls to execute."""
        return bool(self.tool_calls or self.sub_agent_calls or self.batch_agent_calls)

    def get_call_summary(self) -> str:
        """Get a summary of all calls."""
        summary_parts: list[str] = []
        if self.tool_calls:
            summary_parts.append(f"{len(self.tool_calls)} tool calls")
        if self.sub_agent_calls:
            summary_parts.append(
                f"{len(self.sub_agent_calls)} sub-agent calls",
            )
        if self.batch_agent_calls:
            summary_parts.append(
                f"{len(self.batch_agent_calls)} batch agent calls",
            )

        if summary_parts:
            return ", ".join(summary_parts)
        return "no calls"
